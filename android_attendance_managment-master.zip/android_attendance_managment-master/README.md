# Android Attendance Managment
Attendance Management System for Colleges.
Has Semester wise Subjects and Teachers. 
Two account types supported - Administrator and User.
Admin has rights to add users and mark their attendance according to the date. 
View the complete data in tabular format. View user details and info.

* Two accounts (Admin, User)
* Track and Mark daily attendence or for a custom date.
* Export consolidated attendance in HTML tables
* View consolidated attendance as per user.
* Basic UI
