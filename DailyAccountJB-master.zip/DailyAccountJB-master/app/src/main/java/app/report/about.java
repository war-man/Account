package app.report;

import android.app.Activity;
import android.os.Bundle;

import app.report.R;
import app.report.R.layout;

public class about extends Activity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.about);
    }
}
