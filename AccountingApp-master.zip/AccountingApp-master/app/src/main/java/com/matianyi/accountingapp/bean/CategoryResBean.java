package com.matianyi.accountingapp.bean;

public class CategoryResBean {
    public String title;
    public int resBlack;
    public int resWhite;
}
