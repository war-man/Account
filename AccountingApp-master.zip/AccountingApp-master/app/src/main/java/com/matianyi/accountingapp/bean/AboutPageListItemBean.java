package com.matianyi.accountingapp.bean;

public class AboutPageListItemBean {
    private int itemIcon;
    private String info;

    public int getItemIcon() {
        return itemIcon;
    }

    public void setItemIcon(int itemIcon) {
        this.itemIcon = itemIcon;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }
}


