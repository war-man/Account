package net.zombie_sama.accountbook.event;

public class CategoryUpdateEvent extends DataUpdateEvent {
}
