package net.zombie_sama.accountbook.event;

public class DataUpdateEvent {
}
