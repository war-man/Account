# Android-Event-App-With-User-Accounts
A fully cloud backed mobile application that allows creating accounts associated with the application 
