package stream.com.streamapp.home;

import android.view.View;

/**
 * Created by KathyF on 2017/12/8.
 */

public interface MyItemLongClickListener {
    void onLongItemClick(View view, int position);
}
