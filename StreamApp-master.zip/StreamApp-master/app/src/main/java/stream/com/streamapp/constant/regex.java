package stream.com.streamapp.constant;

/**
 * Created by Alan on 2017/11/5.
 */

public class regex {
    public static final String passwdPattern="passwd<br>.*?<br>";
    public static final String phonePattern="^[1][3,4,5,8][0-9]{9}$";
    //<br>id<br>1<br>
    public static final String idPattern="<br>id<br>.*?<br>";
    public static final String resultPattern="<br>.*<br>";


}
