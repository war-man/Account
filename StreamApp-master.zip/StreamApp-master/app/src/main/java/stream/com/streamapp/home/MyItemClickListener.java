package stream.com.streamapp.home;

import android.view.View;

/**
 * Created by KathyF on 2017/12/6.
 */

public interface MyItemClickListener {
    public void onItemClick(View view, int postion);
}
