package com.example.ai.accountbook;

import java.io.Serializable;

/**
 * Created by AI on 2018/1/31.
 */

/**
 * 可序列化
 */
public class CostBean implements Serializable{
    public String costTitle;
    public String costDate;
    public String costMoney;

}
