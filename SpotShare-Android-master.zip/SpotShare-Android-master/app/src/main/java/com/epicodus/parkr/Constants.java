package com.epicodus.parkr;

/**
 * Created by Ryan on 7/8/2016.
 */
public class Constants {
    public static final String FIREBASE_CHILD_USERS = "users";
    public static final String FIREBASE_CHILD_SPOTS = "spots";

}
